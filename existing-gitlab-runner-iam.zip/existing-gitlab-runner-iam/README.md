### 1. Save the YAML files

```sh
mkdir -p crossplane/gitlab-runner-iam
cd crossplane/gitlab-runner-iam
```

## 📁 File Structure
gitlab-runner-crossplane-aws/
├── 1_policy.yaml
├── 2_role.yaml
├── 3_role_attachment.yaml
├── 4_instance_profile.yaml
└── README.md

# 📦 Full Resource Chain
| Resource File             | Purpose                                 |
| ------------------------- | --------------------------------------- |
| `1_iam-policy.yaml`       | Defines permissions GitLab Runner needs |
| `2_iam-role.yaml`         | Trust policy for EC2 to assume IAM role |
| `3_iam-attachment.yaml`   | Attaches policy to the IAM role         |
| `4_instance-profile.yaml` | Binds role to instance profile          |

### 🛠️ 2. Apply the YAMLs in order

```sh
# Step 1: Create IAM resources in Crossplane
kubectl apply -f 1_policy.yaml
kubectl apply -f 2_role.yaml
kubectl apply -f 3_role_attachment.yaml
kubectl apply -f 4_instance_profile.yaml

# Step 2: Attach profile to existing instance
aws ec2 associate-iam-instance-profile \
  --instance-id i-0123456789abcdef0 \
  --iam-instance-profile Name=gitlab-runner-instance-profile
```

✅ Outcome: 
- EC2 instance is launched by Crossplane
- IAM role is attached via instance profile
- GitLab Runner (or other software) can assume this role immediately
___________________________________________________________________

# Also confirm on the AWS Console under IAM → Roles.

### 🔒 IAM Permissions Granted
The IAM policy includes:

- ec2:*
- eks:*
- ecr:*
- cloudformation:*
- s3:*
- logs:*
- iam:PassRole